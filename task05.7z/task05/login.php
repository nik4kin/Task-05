<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Login</title>
    </head>
<style>
    li {list-style: none;}
</style>
<body>
	<header>
    <h3><a href="index.html">На главную.</a></h3>
    </header>
    <h2>Вход. Введите логин и пароль:</h2>
    <ul>
        <form name="insert" action="login.php" method="POST" >
            <li>Имя пользователя:</li><li><input type="text" name="user_name" /></li>
            <li>Пароль:</li><li><input type="password" name="password" /></li>
            <li><input type="submit" /></li>
        </form>
    </ul>
    </body>
</html>	
	<?php
	$check = false;
	try {
	$dbuser = 'postgres';
	$dbpass = 'test123';
	$host = 'localhost';
	$dbname='postgres';
	$conn = new PDO("pgsql:host=$host; dbname=$dbname", $dbuser, $dbpass);
	}
	catch (PDOException $e) {
		echo "Error : " . $e->getMessage() . "<br/>";
		die();
		}
	// print $_POST['user_name'];
	// print $_POST['password'];
	$sql = 'SELECT user_name, password FROM users ORDER BY user_name';
	foreach ($conn -> query($sql) as $row) {
		if ($_POST['user_name'] == $row['user_name'] && $_POST['password'] == $row['password'])	{
			print 'Logged in as:'." ";
			print $row['user_name'] . "<br>";
			$check = true;
		}
	}
	if ($check != true) { 
	print "There is no such user or wrong password =(<br>";
	}
	$check = false;	
	?>