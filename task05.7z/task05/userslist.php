<!DOCTYPE html>
<head>
    <title>Users list</title>
    <meta charset="utf-8">
</head>
<body>
	<header>
    <h3><a href="index.html">На главную.</a></h3>
    </header>
</body>
<?php
print 'Таблица пользователей:<br>';
try {
	$dbuser = 'postgres';
	$dbpass = 'test123';
	$host = 'localhost';
	$dbname='postgres';
	$conn = new PDO("pgsql:host=$host; dbname=$dbname", $dbuser, $dbpass);
	}
	catch (PDOException $e) {
		echo "Error : " . $e->getMessage() . "<br/>";
		die();
		}

$sql = 'SELECT user_name, password FROM users ORDER BY user_name';
foreach ($conn -> query($sql) as $row) {
	print $row['user_name'] . " ";
	print $row['password'] . "<br>";
	}
?>