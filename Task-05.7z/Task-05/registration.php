<!DOCTYPE html>
<head>
    <title>Registration</title>
    <meta charset="utf-8">
</head>
<style>
    li {list-style: none;}
</style>
<body>
    <h2>Введите логин и пароль</h2>
    <ul>
        <form name="insert" action="registration.php" method="POST" >
            <li>Имя пользователя:</li><li><input type="text" name="user_name" /></li>
            <li>Пароль:</li><li><input type="password" name="password" /></li>
            <li><input type="submit" /></li>
        </form>
    </ul>
</body>
</html>
<?php
$db = pg_connect("host=localhost port=5432 dbname=postgres user=postgres password=test123");
$query = "INSERT INTO users VALUES ($_POST[user_name]','$_POST[password]')";
$result = pg_query($query); 
?>